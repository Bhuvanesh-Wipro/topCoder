#!/bin/bash

# Set up the environment
source venv/bin/activate  # Activate the virtual environment if you have one

# Load environment variables from .env file
source .env

# Run the Python script
python app.py
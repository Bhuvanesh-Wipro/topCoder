Please try running the app.py by the following process before using the bash script and docker.

Deployment Instructions
API_KEY = "AIzaSyAr1IguLpWANnX1-gJBRM6MuBy-LNk7y-g"

1. Open IDE for python
2. Navigate to the project directory
3. Create a virtual environment (optional but recommended)
4. Install the required libraries from the requirements.txt
5. Set up the environment variables:
- Create a `.env` file in the project directory.
- Add the following lines to the `.env` file:
  ```
  gemini_API_Key=your_gemini_api_key
  csv_path=path_to_your_csv_file
  ```
- Replace `your_gemini_api_key` with your actual Gemini API key.
- Replace `path_to_your_csv_file` with the path to your CSV file.
## Usage
1. Run the script(app.py):
2. The script will read the CSV file, generate responses using the GenerativeAI API, and save the results in a new CSV file named `testDataSolution.csv`.
3. Check the generated CSV file for the responses.
